
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255, 204, 100);

circle(180, 120, 80);
  
rect(160, 155, 40, 140);

line(160, 155, 90, 105)
 
line(260, 115, 200, 160)

line(100, 350, 160, 295)

line(260, 350, 200, 295)
  
rect(174, 300, 13, 40)
  
 circle(173, 300, 15) 
  
 circle(188, 300, 15);

let c = color('magenta');
fill(c);
circle(195, 115, 15);
circle(165, 115, 15);
rect(165, 135, 30, 5)
  
  let value = alpha(c);
  fill(value);
rect(0, 0, 0, 0);



  




}














    